const shopToggle = document.getElementById("shopToggle");
const shopPanel = document.getElementById("shopPanel");

// Toggle dropdown on click
shopToggle.addEventListener("click", (e) => {
  e.preventDefault();
  shopPanel.classList.toggle("open");
});

// Optional: Close dropdown when clicking outside
document.addEventListener("click", (e) => {
  if (!shopPanel.contains(e.target) && !shopToggle.contains(e.target)) {
    shopPanel.classList.remove("open");
  }
});


 function showBuy(card) {
    // Hide all Buy buttons
    document.querySelectorAll('.card .buy').forEach(el => el.classList.add('hidden'));
    
    // Show only the Buy button in clicked card
    const buy = card.querySelector('.buy');
    if (buy) buy.classList.remove('hidden');
  }
  
  function toggleProfileMenu() {
    const dropdown = document.getElementById("profileDropdown");
    dropdown.classList.toggle("hidden");
  }

  function logout() {
    localStorage.removeItem("loggedInUser");
    window.location.href = "login.html";
  }

  // Optional: Show username if logged in
  window.addEventListener("DOMContentLoaded", () => {
    const user = localStorage.getItem("loggedInUser");
    if (user) {
      document.getElementById("profileName").innerText = user;
    }
  });

  // Close dropdown when clicking outside
  document.addEventListener("click", function (e) {
    const dropdown = document.getElementById("profileDropdown");
    const button = document.querySelector("button[onclick='toggleProfileMenu()']");
    if (!dropdown.contains(e.target) && !button.contains(e.target)) {
      dropdown.classList.add("hidden");
    }
  });


